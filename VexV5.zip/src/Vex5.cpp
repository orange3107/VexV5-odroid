#include "Vex5.h"
#include "firmware.h"
#include "string.h"

Vex5_t Vex5;

int8_t Vex5_t::begin(int32_t speed, int8_t chip_select, int8_t is_reset)
{
  begin_internal_protocol(speed, chip_select);
  int8_t result = -1;
  uint8_t data[256];
  delay(100);
  
  resync();
  delay(100);
  if(is_reset)
  {
    sendData((VEX5_DEVICE_ID_t)1, VEX5_CMD_RESET, data, 0);
    sendData((VEX5_DEVICE_ID_t)1, VEX5_CMD_RESET, data, 0);
    sendData((VEX5_DEVICE_ID_t)0, VEX5_CMD_RESET, data, 0);
    sendData((VEX5_DEVICE_ID_t)0, VEX5_CMD_RESET, data, 0);
    delay(500);
  }


  sendData((VEX5_DEVICE_ID_t)0, VEX5_CMD_POWER_ON, data, 0);
  if(receiveData(data) == -1)
    return -1;
  sendData((VEX5_DEVICE_ID_t)1, VEX5_CMD_START, data, 0);
  delay(300);

  return 0;
}

int8_t Vex5_t::begin_bootloader(int32_t speed, int8_t chip_select)
{
  begin_internal_protocol(speed, chip_select);
  delay(100);
  resync();
  delay(100);
  return 0;
}

int8_t Vex5_t::updateFirmware()
{
  uint8_t data[256];

  for(int deviceNumber = 0; deviceNumber < 2; deviceNumber++)
  {
    int8_t result = -1;
    uint8_t size = sizeof(firmwareData) / 2048;
    if(sizeof(firmwareData) % 2048)
    {
  	 size++;
    }
    data[0] = size;
    sendData((VEX5_DEVICE_ID_t)deviceNumber, VEX5_CMD_ERASE, data, 1);
    delay(200);
    if(receiveData(data) == -1)
    {
      return -1 - deviceNumber * 10;
    }

    for (uint32_t i = 0; i < sizeof(firmwareData); i += 64)
    {
      data[0] = i;
    	data[1] = i >> 8;
    	data[2] = i >> 16;
    	data[3] = i >> 24;
    	for(int j = 0; j < 64; j++)
    	{
          data[4 + j] = pgm_read_byte_near(firmwareData + i + j);
    	}
    	sendData((VEX5_DEVICE_ID_t)deviceNumber, VEX5_CMD_UPDATE_FIRMWARE, data, 64 + 4);
    	delay(30);
      if(receiveData(data) == -1)
      {
        return -2 - deviceNumber * 10;
      }
    }
  }

  sendData((VEX5_DEVICE_ID_t)1, VEX5_CMD_START, data, 0);
  delay(10);
  sendData((VEX5_DEVICE_ID_t)0, VEX5_CMD_START, data, 0);
  delay(10);

  return 0;
}
